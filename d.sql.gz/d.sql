CREATE TABLE public."CustomerImportRow" (
